// This is a JavaScript file

var YOUR_APP_KEY = "YOUR_APP_KEY";
var YOUR_CLIENT_KEY = "YOUR_CLIENT_KEY";
$(function(){
//起動時にmobile backend APIキーを設定
    NCMB.initialize(YOUR_APP_KEY,YOUR_CLIENT_KEY);
});

function installation_status(){
    var InstallationCls = NCMB.Object.extend("installation");
    var query = new NCMB.Query(InstallationCls);
    query.get("Object_id", {
        success: function(inst) {
            //端末のPlaceの値を設定
            inst.set("Place", "place");
            //端末のAgeの値を設定
            inst.set("Age", "age");
            inst.save(null, {
                success: function(obj) {
                    // 保存完了後に実行される
                    alert("プッシュ通知受信登録成功！"); 
                },
                error: function(obj, error) {
                    // エラー時に実行される
                    alert("登録失敗！次のエラー発生: " + error.message);
                }
            });
        }, 
        error: function(inst, error) {
            alert("登録失敗！次のエラー発生: " + error.message);
        }
    });
}